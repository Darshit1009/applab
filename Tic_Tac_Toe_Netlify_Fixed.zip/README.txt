Tic Tac Toe — Netlify-ready static web app

Deploy:
1. Extract this ZIP.
2. Upload the folder containing index.html, style.css, and code.js to Netlify
   using the manual deploy area, or connect this folder to a Git repository.
3. No build command or publish directory setting is required when deploying
   the folder itself; the site root contains index.html.

This version uses standard HTML, CSS, and JavaScript. It does not depend on
Code.org App Lab runtime APIs, so the game logic works as a standalone website.
